package com.HaHa.SocketUser;

import android.app.*;
import android.os.*;
import android.view.*;
import java.net.*;
import android.widget.*;
import android.graphics.*;
import android.util.*;
import java.io.*;

public class MainActivity extends Activity 
{
	Socket socket;
	String IPSet;
	int PortSet;
	String MessageSet;
	String NameSet;
	boolean isStarted = false;
	boolean isConnected = false;
	boolean isFirstsend = true;
	boolean canFinish = false;
	Button startButton;
	Button sendButton;
	EditText IP;
	EditText Port;
	EditText Message;
	TextView MainTextView;
	TextView NameTextView;
	ScrollView MainScrollview;
	BufferedReader BR;
	PrintWriter PW;
	Thread T;
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		
		IP = (EditText)findViewById(R.id.IPText);
		Port = (EditText)findViewById(R.id.PointText);
		Message = (EditText)findViewById(R.id.Message);
		MainTextView = (TextView)findViewById(R.id.mainTextView);
		NameTextView = (TextView)findViewById(R.id.Name);
		MainScrollview = (ScrollView)findViewById(R.id.MainScrollView);
		startButton = (Button)findViewById(R.id.satrtButton);
		sendButton = (Button)findViewById(R.id.sendButton);
		
		
    }

	Handler handler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			// TODO: Implement this method
			super.handleMessage(msg);
			
			switch(msg.what){
				case 0:if(socket == null){
						
						T.interrupt();
						
						MainTextView.setText(MainTextView.getText() + "\n" + "超时，请检查重试");
						
						}
						break;
				case 1:MainTextView.setText(MainTextView.getText() + "\n" + (String)msg.obj);
					handler.post(new Runnable() {
							@Override
							public void run() {
								MainScrollview.fullScroll(ScrollView.FOCUS_DOWN);
							}
						});
				break;
			}
			
		}
		
	};
	
	
	@Override
	public void finish() {
		// TODO: Implement this method
		if(T != null){
			T.interrupt();
		}
		
		try{
			

			if(PW != null){
				if(NameSet != null){
				PW.println("<---- " + NameSet + "离开了 ---->");
				PW.flush();
				}
				PW.close();
			}
			
			
			if(BR != null){
				BR.close();
			}
			
			if(socket != null){
				socket.close();
			}
			}
			catch (IOException e) {}
		super.finish();
		
	}
	
	
	
	public void onStartButtonClick(View view){
		if(canFinish){
			finish();
			return;
		}
		
		
		if(isStarted == false ){
			
			MainTextView.setText(MainTextView.getText() + "\n" + "请稍候。。。");
			
			String[] IPList = IP.getText().toString().split("\\.");//  \\转义符号
			
			try{
				if(IPList.length == 4){
					int[] I = new int[4];
					
					for(int i = 0; i < 4 ; i++){
						I[i] = Integer.parseInt(IPList[i]);
						
						if(I[i] > 255 || I[i] < 0){
							throw new Exception();
						}
					}
				}else{
					throw new Exception();
				}
			}catch(Exception e){
				Toast.makeText(this,"地址有误!!",Toast.LENGTH_SHORT).show();
				return;
				}
			
			
			try{
				int I = Integer.parseInt(Port.getText().toString());
				if(I < 1024 || I > 65536){
					throw new Exception();
				}
			}catch(Exception e){
				Toast.makeText(this,"有误!!!!!",Toast.LENGTH_SHORT).show();
				return;
			}
			
			IPSet = IP.getText().toString();
			PortSet = Integer.parseInt(Port.getText().toString());
			

			isStarted = true;
			
			
			T = new Thread(new SocketMethod());
			T.start();
			
			new Thread(){
				public void run(){
					try {
						this.sleep(5000);
						
						Message M = new Message();
						
						M.what = 0;
						handler.sendMessage(M);
					}
					catch (InterruptedException e) {}
				}
			}.start();
			
			
			while(T.isAlive()){}
			if(socket == null){
				isStarted = false;
				return;
			}else{
				isConnected = true;
				
				startButton.setText("退出");
				canFinish = true;
				
				Message.setFocusable(true);
				Message.setFocusableInTouchMode(true);
				Message.requestFocus();
				Message.requestFocusFromTouch();
				MainTextView.setText(MainTextView.getText() + "\n" + "成功连接!\n设置你的昵称");
				sendButton.setText("确定");
				
			}
			
			T = new Thread(new SocketMethod());
			T.start();
			
			
		}
		
	}
	
	public void onSendButtonClick(View view){
		if(isConnected){
		if(socket == null){
			Toast.makeText(this,"连接中，请等等。。。。",Toast.LENGTH_SHORT).show();
			return;
		}
		if(isFirstsend){
			NameSet = Message.getText().toString();
			isFirstsend = false;
			NameTextView.setText(NameTextView.getText().toString() + NameSet);
			MainTextView.setText(MainTextView.getText().toString() + "\n" +"OK");
			sendButton.setText("发送");
			PW.println("<---- "+ NameSet +" 加入了 ---->");
			PW.flush();
			Message.setText("");
		}else{
			if(Message.getText().toString() != null){
			MessageSet = NameSet + ":\n    " +Message.getText().toString();
		
			PW.println(MessageSet);
		
			PW.flush();//清空缓冲区
		
			Message.setText("");
		}}
		}
	}
	
	
	
	
	
	
	public class SocketMethod implements Runnable
	{
		

		@Override
		public void run() {
			// TODO: Implement this method
			if(socket == null){
				try{
					
					socket = new Socket(IPSet,PortSet);
					BR = new BufferedReader(new InputStreamReader(socket.getInputStream()));
					PW = new PrintWriter(socket.getOutputStream());
				}catch(Exception e){
				}
			}else{
				String Messages;
				try{
				while((Messages = BR.readLine()) != null){
					
					Message M = new Message();
					M.what = 1;
					M.obj = Messages;
					handler.sendMessage(M);
					
					
				}
				}catch(IOException e){}
			}
			
		}


	}
	
}
